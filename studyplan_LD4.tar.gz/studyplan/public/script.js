function openLightbox(panelId) {
  document.querySelectorAll('.lb-panel').forEach(p => p.style.display = 'none');
  document.getElementById(panelId).style.display = 'block';
  document.getElementById('lightbox').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeLightbox() {
  document.getElementById('lightbox').classList.remove('open');
  document.body.style.overflow = '';
}
function closeLightboxBg(e) {
  if (e.target === document.getElementById('lightbox')) closeLightbox();
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });

function playDemo1() {
  document.getElementById('po1').classList.add('hidden');
  const items = ['atz1','at1','at2','at3','at4'];
  items.forEach((id,i) => {
    const el = document.getElementById(id);
    el.classList.remove('in');
    setTimeout(() => el.classList.add('in'), 300 + i * 500);
  });
  setTimeout(() => {
    const pb = document.getElementById('pb1');
    pb.style.width = '0';
    requestAnimationFrame(() => { pb.style.width = '80%'; });
  }, 300 + items.length * 500);
  setTimeout(() => {
    document.getElementById('po1').classList.remove('hidden');
    items.forEach(id => document.getElementById(id).classList.remove('in'));
  }, 5500);
}

function playDemo2() {
  document.getElementById('po2').classList.add('hidden');
  const steps = ['ea-env','ea-body','ea-sent'];
  steps.forEach((id,i) => {
    const el = document.getElementById(id);
    el.classList.remove('in');
    setTimeout(() => el.classList.add('in'), 400 + i * 900);
  });
  setTimeout(() => {
    document.getElementById('po2').classList.remove('hidden');
    steps.forEach(id => document.getElementById(id).classList.remove('in'));
  }, 5500);
}

const themeBtn = document.getElementById('theme-btn');
const html = document.documentElement;
try {
  const saved = localStorage.getItem('sp-theme') || 'light';
  if (saved === 'dark') { html.setAttribute('data-theme','dark'); themeBtn.textContent = '☀️'; }
} catch(e) { /* localStorage unavailable — ignore */ }

themeBtn.addEventListener('click', () => {
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  themeBtn.textContent = isDark ? '🌙' : '☀️';
  try { localStorage.setItem('sp-theme', isDark ? 'light' : 'dark'); } catch(e) {}
});

const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobile-menu');
hamburger.addEventListener('click', () => mobileMenu.classList.toggle('open'));
function closeMobile() { mobileMenu.classList.remove('open'); }

function changeColor(el) {
  document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
  el.classList.add('active');
  const color = el.dataset.color;
  const target = document.getElementById('color-target');
  target.style.background = color;
  const isDark = ['#1a2744'].includes(color);
  target.style.color = isDark ? '#e8b96a' : '';
  document.getElementById('color-label').innerHTML = `Background is: <strong>${color}</strong>`;
}

let currentSize = 14;
function changeSize(delta) {
  currentSize = Math.min(26, Math.max(10, currentSize + delta));
  applySize();
}
function sliderSize(val) {
  currentSize = parseInt(val);
  applySize();
}
function applySize() {
  document.getElementById('font-sample').style.fontSize = currentSize + 'px';
  document.getElementById('size-label').textContent = currentSize + 'px';
  document.getElementById('font-slider').value = currentSize;
}

function toggleVis(panelId, btnId) {
  const panel = document.getElementById(panelId);
  const btn = document.getElementById(btnId);
  const isVisible = panel.classList.contains('visible');
  panel.classList.toggle('visible', !isVisible);
  btn.textContent = isVisible ? 'Show' : 'Hide';
  btn.className = 'vis-btn ' + (isVisible ? 'show' : 'hide');
}

function toggleSwitch(el) {
  el.classList.toggle('on');
}

function showToast() {
  const t = document.getElementById('notif-toast');
  t.style.display = 'block';
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(hideToast, 6000);
}
function hideToast() {
  const t = document.getElementById('notif-toast');
  t.classList.remove('show');
  setTimeout(() => { t.style.display = 'none'; }, 420);
}

function submitTask() {
  const titleEl    = document.getElementById('task-title');
  const courseEl   = document.getElementById('task-course');
  const emailEl    = document.getElementById('task-email');
  const deadlineEl = document.getElementById('task-deadline');
  const notifEl    = document.getElementById('task-notif');
  const priorityEl = document.getElementById('task-priority');
  const typeEl     = document.getElementById('task-type');
  const success    = document.getElementById('form-success');

  const title    = titleEl.value.trim();
  const course   = courseEl.value.trim();
  const email    = emailEl.value.trim();
  const deadline = deadlineEl.value;
  const notif    = notifEl.value;
  const priority = priorityEl.value;   // "high" | "medium" | "low"
  const type     = typeEl.value;

  if (!title || !email || !deadline || !notif) {
    alert('Please fill in all required fields: Task Title, Notification Email, Deadline, and Email Notification Time.');
    return;
  }

  // Map select value → CSS class suffix (fixes medium → med bug)
  const priorityClass = { high: 'high', medium: 'med', low: 'low' }[priority] || 'med';
  const priorityLabel = priority.toUpperCase();

  // Format deadline for display in university TZ
  const deadlineDate = new Date(deadline);
  const deadlineStr  = deadlineDate.toLocaleDateString('en-GB', { day:'2-digit', month:'short' })
                     + ' · '
                     + deadlineDate.toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit' });

  // Build new task row and insert into dashboard task list
  const taskList = document.getElementById('tasks-list');
  const newTask  = document.createElement('div');
  newTask.className = 'task-item';
  newTask.style.cssText = 'animation: taskSlideIn .45s cubic-bezier(.4,0,.2,1); border-left: 3px solid var(--gold);';
  newTask.innerHTML = `
    <span style="flex:1;font-size:.88rem;font-weight:500">
      ${title}${course ? ' — ' + course : ''}
      <small style="display:block;color:var(--muted);font-size:.75rem;font-weight:400;margin-top:.15rem">
        ${type} &nbsp;·&nbsp; 📧 Email reminder scheduled &nbsp;·&nbsp; EET (UTC+2)
      </small>
    </span>
    <span style="font-size:.8rem;color:var(--muted);white-space:nowrap;flex-shrink:0">${deadlineStr}</span>
    <span class="priority-badge p-${priorityClass}">${priorityLabel}</span>
  `;
  taskList.appendChild(newTask);

  // Update the task counter badge
  const countEl = document.getElementById('task-count');
  if (countEl) countEl.textContent = taskList.querySelectorAll('.task-item').length;

  // Scroll db-main internally so new task is visible
  const dbMain = document.querySelector('.db-main');
  dbMain.scrollTo({ top: dbMain.scrollHeight, behavior: 'smooth' });

  // Scroll entire page up to dashboard so user sees the task appear
  setTimeout(() => {
    document.getElementById('dashboard').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 150);

  // Flash gold highlight on new task so it's impossible to miss
  newTask.style.background = 'rgba(201,150,58,0.35)';
  newTask.style.transition = 'background 2s ease';
  setTimeout(() => { newTask.style.background = ''; }, 2500);


  // Show success banner with notification confirmation
  const notifFormatted = new Date(notif).toLocaleString('en-GB', {
    day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit',
    timeZone: 'Europe/Vilnius'
  });
  success.style.display = 'block';
  success.textContent = `✅ "${title}" added to your dashboard! Email notification scheduled for ${notifFormatted} EET.`;
  setTimeout(() => { success.style.display = 'none'; }, 7000);

  // Reset form fields
  ['task-title','task-course','task-desc','task-email'].forEach(id => document.getElementById(id).value = '');
  deadlineEl.value   = '';
  notifEl.value      = '';
  priorityEl.value   = 'medium';
  typeEl.value = 'Assignment';
}

document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
  });
});

const sections = document.querySelectorAll('section[id], header[id]');
const titleObserver = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      const labels = {
        home:'Home', features:'Features', how:'How It Works',
        dashboard:'Dashboard', 'create-task':'Create Task',
        notifications:'Notifications', gallery:'Gallery',
        videos:'Videos', playground:'Playground', tech:'Tech Stack', faq:'FAQ'
      };
      document.title = (labels[e.target.id] || 'StudyPlan') + ' · StudyPlan';
    }
  });
}, { threshold: 0.4 });
sections.forEach(s => titleObserver.observe(s));
